from django.apps import AppConfig


class UsmanajibolaabassscrumyConfig(AppConfig):
    name = 'usmanajibolaabassscrumy'
